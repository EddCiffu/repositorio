
#Tema 01: carga de datos ----

# Cargar datos ----

## Carga local
DF <- read.csv(file = "Personalidad y uso de apps (respuestas) - Respuestas de formulario 1.csv",
               check.names = FALSE)



## Carga en linea ----

install.packages("gsheet")
library(gsheet)

DF <- read.csv(text = gsheet2text(url = "https://docs.google.com/spreadsheets/d/1IQ_RxxTSmBKHTExlxboIRNlMov_F6RyqdcOPrflCv_w/edit?usp=sharing"),
               check.names = F)
# Estructura del data frame ----

class(DF)
nrow(DF)
ncol(DF)

class(DF$`Escribe tu edad exacta`)
class(DF$Sexo)

#Tema 02: Transformacion de datos ----

## Valores perdidos ----

DF$`Escribe tu edad exacta`
is.na(DF$`Escribe tu edad exacta`)
summary(is.na(DF$`Escribe tu edad exacta`)) #ME CONTABILIZA LOS NA


### Remplazo con la media ----
install.packages("tidyverse")
library(tidyverse)

DF2 <- DF %>%
  mutate(`Escribe tu edad exacta`= ifelse(test=is.na(`Escribe tu edad exacta`),
                                          yes=mean(`Escribe tu edad exacta`, na.rm = T),
                                          no=`Escribe tu edad exacta`)) #mi primera funcion logica, is.na es para pillar las NA, usamos ifelse como funcion SI de excel y usamos test para comezar a elaborar nuestra funcion, usamos yes para referirnos a que si pilla un NA tiene que buscar la media de todo y colocar eso ahi, na.rm=T es para que omita todas las NA y pueda realizar el calculo y sacar el promedio, y si no hay NA simplemente escribe los datos.
### Eliminar la fila completa ----

DF2<-DF %>% na.omit() #esta formula me quita directamente las filas donde habia NA, COMO SI NUNCA HUBIERA RESPONDIDO LA ENCUESTA ESA PERSONA

## Estandarizacion de varaibles ----

### Noralizacion: ES AGARRAR EL PROMEDIO Y CONVERTIRLO EN 0 Y AGARRAMOS LA DESVIACION ESTANDAR Y LA CONVERTIMOS A 1, Convertir la media en 0 y los valores expresados en desviacionees respecto a la media ----

scale(DF2$`Escribe tu edad exacta`)
data.frame(original = DF2$`Escribe tu edad exacta`,
normalizado = scale(DF2$`Escribe tu edad exacta`)) %>%
  head(n=10) #esta formula es para mostrar los 10 primeros casos nada mas
mean(DF2$`Escribe tu edad exacta`) #PROMEDIO, LA NORMALIZACION CONVIERTE EL PROMEDIO EN 0
sd(DF2$`Escribe tu edad exacta`) #PARA SACAR LA DESVIACION ESTANDAR DE LA EDAD, la columna normalizado, los numeros que salen ahi nos muestra cuantas veces esta por encima o abajo del promedio la edad, se multiplica la desviacion estandar por ese numero y se saca la edad, QUE ES LA DEVIACION ESTANDAR: es la desviacion promedio de las encuestas con respecto al promedio

#Agregar una nueva columna al DF2 Y ESA NUEVA COLUMNA SERIA EL scale(edad)

DF3 <- DF2 %>% #CON DF3 GUARDE TOODO LO QUUE HICE EN UN NUEVO DATAFREM
  #la funcion mutate es para agregar nuevas varaibles
  mutate(Edad.Z = scale(`Escribe tu edad exacta`)) %>%
  relocate(Edad.Z, 
         .after = `Escribe tu edad exacta`)  # para re-ordenar las variables en mi tablita

# Rango: CONVERTIR A RANGO, AGARRA EL VALOR MINIMO. EN ESTE CASO LA EDAD MAS BAJA LA CONVIERTE A 0 Y AGARRA LA EDAD MAS alta Y LA CONVIERTE EN 1 ----
library(scales)

rescale(DF2$`Escribe tu edad exacta`)

data.frame(original = DF2$`Escribe tu edad exacta`,
           rescaled = rescale(DF2$`Escribe tu edad exacta`))

## Agrupaciones ----

### Numericas ----

DF4 <- DF3 %>% 
  
  # Crear la variable que agrupa las edades 
  mutate(Edad.GR = cut(`Escribe tu edad exacta`,
         breaks=c(-Inf, 18, 23, Inf),
         labels = c("18 o menos", "19 a 23", "Mas de 23"))) %>% 
  
  # Re-ubicar la variable
  relocate(Edad.GR,
           .after = Edad.Z) 

### Categoricas ----

unique(DF4$`Según tu forma de ser ¿Cuál de las siguientes frases describe mejor tu forma de ser y pensar? [Me gusta comprar marcas que representen mi status]`) #UNIQUE PARA QUE NOS MUESTRE LAS DOS VARIABLES QUE EXISTEN

colnames(DF4) #con esta funcion nos muestra el numero de columnas
ifelse(test = DF4[,9] == "Un poco verdadero" | DF4[,9] == "Totalmente verdadero", yes = 1, no= 0) #a la derecha de la coma especificamos la columna que queremos, si la columna 9 es un poco verdadero o totalmente verdadero saldra el 1 pero si no es ninguno de esos valores saldra 0 

### (parentesis) Blucle ----

#### paso 1: Crear un vector que contenga el nombre de las variables donde se va a aplicar el bucle
frases <- DF4 %>% select(starts_with("Según tu")) %>% colnames() #su funcion es seleccionaR COLUMNAS ESPECIFICAS DE UN DATAFREM,,SELECT PARA SELECCIONAR UNA COLUMNA ESPECIFICA Y START WITH PARA SOLO LAS QUE COMIENCEN CON LO QUE ESCRIBA

frases

#### CREANDO UN DF POR TEMAS PEDAGOGICOS----
DF5 <- DF4

#### Paso 2: Ejecutar el bucle----
for (variable in frases) {
  
  DF5[,variable] <- ifelse(
    test = DF5[,variable] == "Totalmente verdadero" | DF5[,variable] == "Un poco verdadero",
    yes = 1,
    no = 0
  )
  
} #primero buscamos las variables en el apartado que creamos de frases y a todas les aplicamos ifelse


## Manipulacion de DATA.FRAME ----

#Convirtiendo el data.frame a tibble es igual a tabla
DF5 <- DF5 %>% as_tibble()


### Funcion select (columnas) ----
DF5 %>% select(Sexo)
DF5 %>% select(Sexo,`Escribe tu edad exacta`)
DF5 %>% select(`Marca temporal`)
DF5 %>% select(starts_with("¿Cuánto"))
DF5 %>% select(ends_with("J"))
DF5 %>% select(contains("días"))



### Funcion filter (seleccion de filas) ----
DF5 %>% filter(Sexo == "Mujer")
DF5 %>% filter(Sexo != "Hombre") #Negación
DF5 %>% filter(`Escribe tu edad exacta` >=20) #Mayor o igual que
DF5 %>% filter(`Escribe tu edad exacta` <=20) #Menor o igual que
DF5 %>% filter(`Escribe tu edad exacta` >=20 & `Escribe tu edad exacta` <=21) #Rango

# Ejercicio 1 : Mujer entre 15 y 18----
DF5 %>% filter(Sexo == "Mujer", `Escribe tu edad exacta` >=15 & `Escribe tu edad exacta` <=18)

# Ejercicio 2: ----
# Columnas: Solo variable de edad y [Me gusta comprar marcas que representen mi estatus]
# Filas: [Me gusta comprar marcas que representen mi estatus]

DF5 %>% select(`Escribe tu edad exacta`, `Según tu forma de ser ¿Cuál de las siguientes frases describe mejor tu forma de ser y pensar? [Me gusta comprar marcas que representen mi status]`) %>% 
                 filter(`Según tu forma de ser ¿Cuál de las siguientes frases describe mejor tu forma de ser y pensar? [Me gusta comprar marcas que representen mi status]` == "1")

### Cambio de nombre de columnas ----
DF6 <- DF5
colnames(DF6)

##APPS
## Paso 1: Creamos un vector con los nuevos nombres 
apps <- c("TikTok", "Instagram", "Facebook", "YouTube")

#Paso 2: Reemplazar los nombres antiguos por los del vector creado 
colnames(DF6)[33:36] <- apps
colnames(DF6)

# Frases
## Paso 1: Creamos un vector con los nuevos nombres 
frases2 <- frases %>% 
  as_tibble() %>% #primero se transforma el data frame a una tabla
  separate(col = value, #se crea una columna llamada value 
           into = c("No sirve", "Sirve"), #y le pedimos que separe lo que sirve y lo que no sirve
           sep = "\\[") %>% 
  select(-"No sirve") %>% #el menos por que estamos eliminando la columna
  separate(col = Sirve,
           into = c("Sirve", "No Sirve"),
           sep = "\\]") %>%
  select(-"No Sirve") %>%
  as_vector()
  
           
  
 
#Paso 2: Reemplazar los nombres antiguos por los del vector creado 
colnames(DF6)[8:31] <- frases2
colnames(DF6)


### Pivotado de base ---- #vamos a hacer la base de datos mas larga en filas y disminuyendo las columnas 

DF7 <- DF6 %>% # el del profe
  select(apps) %>%
  pivot_longer(cols = everything(),
               names_to = "apps",
               values_to = "tiempo")

DF7 <- DF6 %>%
   pivot_longer(cols = apps,
               names_to = "apps",
               values_to = "tiempo")

### Pivot wider

DF8 <- DF7 %>%
pivot_wider(names_from = apps,
            values_from = tiempo)

### (Parentesis) Transformacion horas ----

class(DF7$tiempo)
head(DF7$tiempo)

# strsplit separa los textos 

strsplit(x = DF7$tiempo,
         split = ":") %>%
  head()

#transformacion convertimos las hrs a numeros
DF7$tiempo <- sapply(X = strsplit(x = DF7$tiempo,
                    split = ":"),
       function(x){
         
         x <- as.numeric(x)
       x[1] + x[2]/60 + x[3]/60^2
       
       })

### Gráfica : Boxplots ----

# Boxplots feo
boxplot(x = DF7$tiempo)

# Bloxplots bonito
#instalamos el paquete
install.packages("plotly")
library(plotly)

# ggplotly hace que el grafico sea interactivo
ggplotly(
  # Definir el DF
  DF7 %>%
    
    ## Dibujar el lienzo
    ggplot(mapping = aes(x = apps,
                         y = tiempo,
                         fill = apps)) +
             
             # Especificar el tipo de grafico
             geom_boxplot() + 
    geom_jitter(width = .2,
                alpha = .5) +
             
             # Definir el tema
             theme_minimal() +

#otras opciones de tema
theme(legend.position = "none")
) #en mi grafico el q1 es cuando avanzo hasta el 25% de los datos, la media al 50%, el q3 al 75% y el q4 al 100%, en caso de que esten ordenados de menor a mayor #que es un rango intercuartilico: comprende desde el q1 hasta el q3, el bigote que esta desde el 0, se estira hacia el valor maximo cuando no hay errores (outlayers), y en caso de haber outlayers solo se estira 1.5 veces mas basado en el rango intercuartilico, de ahi todos son outlayers


# Mismo grafico pero normalizado ----
ggplotly(
  DF7 %>%
    
    group_by(apps) %>%  #para separar los calculos de cada app en este caso
    
    mutate(scaled = scale(tiempo)) %>%
    
    
    #una vez hecho el calculo, desagrupar 
    
    ungroup() %>%
    
ggplot(mapping = aes(x = apps,
                     y = scale(tiempo),
                     fill = apps)) +

  geom_boxplot() + 
  
  labs(x = "",
       y = "Horas a la semana",
       title = "Cantidad de tiempo en redes sociales") +
  
  theme_minimal() +
  theme(legend.position = "none")
)

#### tratamiento de outliers ----

DF9 <- DF7 %>%
  group_by(apps) %>%
  mutate(scaled = scale(tiempo)) %>%
  ungroup() %>%
  #Remmplazo por NA, es decir, eliminar ----
mutate(time_na = ifelse (test = scaled >2,
                       yes = NA,
                       no = tiempo), 
       time_mean = ifelse(test = scaled >2,
                   yes = median(tiempo),
                   no = tiempo))

        
       
DF10 <- DF7 %>%
  group_by(apps) %>%
  mutate(scaled = scale(tiempo)) %>%
  ungroup() %>%
  #Remmplazo por NA, es decir, eliminar ----
mutate(time_na = ifelse (test = scaled >2,
                         yes = NA,
                         no = tiempo)) %>% 
  mutate(time_median = replace_na(time_na, median(tiempo)))


library(FactoMineR)

### MAPAS PERCEPTUAL 1003----

DF10 <- DF9 %>%
  #Seleccionar solo las variables de interes
  select(Edad.GR,apps,tiempo) %>%
  
  #Sumar el tiempo
group_by(Edad.GR, apps) %>%
  summarise(time_sum = sum(tiempo)) %>%
  
  #desagrupar
  ungroup() %>%

# Pivotear la variable app
  pivot_wider(names_from = apps,
              values_from = time_sum) %>%

#Pasar la columna edad a nombre de fila 
column_to_rownames(var = "Edad.GR")

#Mapa perceptual ahora si

FactoMineR::CA(DF10)

    
#PRACTICANDO----

DF11 <- DF9 %>%
  #Seleccionar solo las variables de interes
  select(Sexo,apps,tiempo) %>%
  
  #Sumar el tiempo
  group_by(Sexo, apps) %>%
  summarise(time_sum = sum(tiempo)) %>%
  
  #desagrupar
  ungroup() %>%
  
  # Pivotear la variable app
  pivot_wider(names_from = apps,
              values_from = time_sum) %>%
  
  #Pasar la columna Sexo a nombre de fila 
  column_to_rownames(var = "Sexo")

#Mapa perceptual ahora si

FactoMineR::CA(DF11)


