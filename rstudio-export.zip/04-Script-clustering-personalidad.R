install.packages("NbClust")
library(NbClust)

#en este tema vamos a hacer el uso del DF7 como base

#Creacion de los clusters----
clustering <- NbClust(data = DF12 %>%
                        select(all_of(dimensiones)),
                      distance = "euclidean",
                      method = "ward.D2",
                      index = "dunn"
)
#Definicion de la cantida de clusters----
plot(clustering$All.index,
     type = "b")

#Creacion de 2 cluster----
clustering.2 <- NbClust(data = DF12 %>%
                        select(all_of(dimensiones)),
                      distance = "euclidean",
                      method = "ward.D2",
                      index = "dunn",
                      #Argumentos para especificar cant. de clusters
                      min.nc = 2 ,
                      max.nc = 2)

#Tabla que muestra el peso de cada cluster
prop.table(table(clustering.2$Best.partition))

#Creacion de 3 cluster (elegido)----
clustering.3 <- NbClust(data = DF12 %>%
                          select(all_of(dimensiones)),
                        distance = "euclidean",
                        method = "ward.D2",
                        index = "dunn",
                        #Argumentos para especificar cant. de clusters
                        min.nc = 3 ,
                        max.nc = 3)

#Tabla que muestra el peso de cada cluster
prop.table(table(clustering.3$Best.partition))

#Analizando los clusters----

## Añadir la clasificacion al DF
DF13 <- DF12 %>%
mutate(segmento = as.factor(clustering.3$Best.partition))

## Cruzar por cada una de las variables ----
