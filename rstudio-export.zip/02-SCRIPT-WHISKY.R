
library(tidyverse)
library(plotly)

glimpse(DF3)



#Generando tablas de frecuencia ----

## Marca que mas compra
ggplotly(
DF3 %>% 
  # Contar los casos
  count(`¿Cuál es la marca que más compra?`) %>%
  # Ordenar la tabla
  arrange(desc(n)) %>%
# Calcular por porcentajes
mutate(porcentaje = round(n/sum(n),
                          digits = 2)) %>%
# Crear un grafico de columnas
    ggplot(mapping = aes(x = `¿Cuál es la marca que más compra?`,
                         y = porcentaje,
                         fill = `¿Cuál es la marca que más compra?`,
                         label = n)) + #para poner etiquetas al grafico
             geom_col() +
  scale_y_continuous(labels = scales::percent) + #para ponerle porcentaje al grafico
  theme(legend.position = "none",
        text = element_text(size = 9)) #para cambiar el tamaño del grafico
)  
  

##Prueba ----

DF3 %>% 
  pivot_longer(cols = starts_with("Prueba"), #Pusimos 4 columnas en una sola
               names_to = "Variable",
               values_to = "Prueba") %>% 
  select(Prueba) %>%
  na.omit() %>% #quito las NA
count(Prueba) %>% #cuenta las marcas y cuantas veces se repiten
mutate(Porcentaje = n/nrow(DF3), #para ver el porcentaje
       #Modifica los numeros a porcentajes reales
       Porcentaje2 = scales::percent(Porcentaje)) %>% 

ggplot(mapping = aes(x = Prueba,
                     y = Porcentaje,
                     fill = Prueba, 
                     label = Porcentaje2)) +
  geom_col() +
  
  #para girar el grafico
  coord_flip() +
  
  #para agregar texto al grafico
  geom_label() +
  
  theme(legend.position = "none")

## Tablas cruzadas ----
DF4 <- DF3 %>%
  select(`Precio razonable`:`Variedad de maduración (años)`) %>%
  pivot_longer(cols = everything(),
               names_to = "atributo",
               values_to = "marca")
table(DF4)

prop.table(table(DF4),
           margin = 1)



prop.table(table(DF4),
           margin = 2) #margen 1 significa que cada una de las filas suma 100 y margen 2 significa que las columnas suman 100 se analiza a cada competidor por separado

### Analisis de correspondencia ----

install.packages("FactoMineR")
library(FactoMineR)

FactoMineR::CA(table(DF4))


# Pregunta de parcial Practicando ----

DF3 %>% 
  pivot_longer(cols = starts_with("atributo"), #Pusimos 7 columnas en una sola
               names_to = "Variable",
               values_to = "atributos") %>%

select(atributos) %>%
  na.omit() %>% #quito las NA
  count(atributos) %>% #cuenta las marcas y cuantas veces se repiten
  mutate(Porcentaje = n/nrow(DF3), #para ver el porcentaje
         #Modifica los numeros a porcentajes reales
         Porcentaje2 = scales::percent(Porcentaje)) %>%

ggplot(mapping = aes(x = atributos,
                     y = Porcentaje,
                     fill = atributos, 
                     label = Porcentaje2)) +
  geom_col() +
  
  #para girar el grafico
  coord_flip() +
  
  #para agregar texto al grafico
  geom_label() +
  
  theme(legend.position = "none") 

















