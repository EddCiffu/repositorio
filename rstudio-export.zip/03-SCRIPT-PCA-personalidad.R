install.packages("ggcorrplot")
library(ggcorrplot)
library(FactoMineR)

# En este tema vamos a hacer uso del DF6 como base ----

#Paso previo: Analizar las correlaciones----

#Convirtiendo frases2 en vector
frases3 <- as.vector(frases2)

#Matriz de correlaciones ----
r <- cor(x = DF6 %>% select(all_of(frases3)),
         method = "spearman") 

##Grafico de matriz de correlaciones----

ggplotly(
  ggcorrplot(corr = r,
             type = "upper",
             show.legend = F,
             colors = c("red", "white", "blue"),
             tl.cex = 14) +
    theme(axis.text.x = element_blank(),
          axis.ticks.x = element_blank(),
          panel.grid.major.x = element_blank())
)

# PCA: Principal components Analysis----

##Dimension : Extroversión----
###Definiendo el vector con las frases----
extroversion <- frases3[c(8,20,23)]
#Creando la dimension----
PCA.extroversion <- FactoMineR::PCA(X = DF6 %>%
                                      select(all_of(extroversion)),
                                    ncp =  1)

# Eigenvalues y varianza explicada---- : Si voy a agrupar 2 variables, altamente correlacionadas, el PCA representara y encerrara todos los puntos que son equivalentes a las encuestas, si el circulo es como una pelota de fut americano hay alta correlacion, si es una circulo no hay mucha correlacion, EL PCA CREA un nuevo eje x y un nuevo eje y y rota el angulo a tal medida que en un angulo specifico que resume a las dos variables seleccionadas, donde abunda mas el grafico, crea una nueva dimension, la linea que se formara se llama eigenvalues
PCA.extroversion$eig

##Correlacion entre la CP1 y las variables originales
PCA.extroversion$var$cor

## Valores de la CP1 (Nueva componente) #si el valor es positivo, significa que la persona se ha identificado con la mayoria de las frases que contiene el componente 1 y si es negativo probablemente no se ha identificado con ninguna

PCA.extroversion$ind$coord %>% head()

### Comparar los valores originales con la CP1
tibble(
  CP1 = PCA.extroversion$ind$coord,
  DF6 %>% select(all_of(extroversion))
) %>% View()



##Dimension : Aventura(*-1)----
###Definiendo el vector con las frases
aventura <- frases3[c(7,19)]
#Creando la dimension
PCA.aventura <- FactoMineR::PCA(X = DF6 %>%
                                      select(all_of(aventura)),
                                    ncp =  1)

# Eigenvalues y varianza explicada : Si voy a agrupar 2 variables, altamente correlacionadas, el PCA representara y encerrara todos los puntos que son equivalentes a las encuestas, si el circulo es como una pelota de fut americano hay alta correlacion, si es una circulo no hay mucha correlacion, EL PCA CREA un nuevo eje x y un nuevo eje y y rota el angulo a tal medida que en un angulo specifico que resume a las dos variables seleccionadas, donde abunda mas el grafico, crea una nueva dimension, la linea que se formara se llama eigenvalues
PCA.aventura$eig

##Correlacion entre la CP1 y las variables originales : cuando vemos una correlacion negativa, significa que la gente mas se relaciona con la variable
PCA.extroversion$var$cor

## Valores de la CP1 (Nueva componente) #si el valor es positivo, significa que la persona se ha identificado con la mayoria de las frases que contiene el componente 1 y si es negativo probablemente no se ha identificado con ninguna

PCA.aventura$ind$coord %>% head()

### Comparar los valores originales con la CP1
tibble(
  CP1 = PCA.aventura$ind$coord,
  DF6 %>% select(all_of(extroversion))
) %>% View()





##Dimension : Tradicional (*-1)----
###Definiendo el vector con las frases
tradicional <- frases3[c(9,14,12)]
#Creando la dimension
PCA.tradicional <- FactoMineR::PCA(X = DF6 %>%
                                  select(all_of(tradicional)),
                                ncp =  1)

# Eigenvalues y varianza explicada : Si voy a agrupar 2 variables, altamente correlacionadas, el PCA representara y encerrara todos los puntos que son equivalentes a las encuestas, si el circulo es como una pelota de fut americano hay alta correlacion, si es una circulo no hay mucha correlacion, EL PCA CREA un nuevo eje x y un nuevo eje y y rota el angulo a tal medida que en un angulo specifico que resume a las dos variables seleccionadas, donde abunda mas el grafico, crea una nueva dimension, la linea que se formara se llama eigenvalues
PCA.tradicional$eig

##Correlacion entre la CP1 y las variables originales
PCA.tradicional$var$cor



##Dimension : Empatia----
###Definiendo el vector con las frases
empatia <- frases3[c(1,18,3)]
#Creando la dimension
PCA.empatia <- FactoMineR::PCA(X = DF6 %>%
                                     select(all_of(empatia)),
                                   ncp =  1)

# Eigenvalues y varianza explicada : Si voy a agrupar 2 variables, altamente correlacionadas, el PCA representara y encerrara todos los puntos que son equivalentes a las encuestas, si el circulo es como una pelota de fut americano hay alta correlacion, si es una circulo no hay mucha correlacion, EL PCA CREA un nuevo eje x y un nuevo eje y y rota el angulo a tal medida que en un angulo specifico que resume a las dos variables seleccionadas, donde abunda mas el grafico, crea una nueva dimension, la linea que se formara se llama eigenvalues
PCA.empatia$eig

##Correlacion entre la CP1 y las variables originales
PCA.empatia$var$cor




##Dimension : Intoversion(*-1)----
###Definiendo el vector con las frases
introversion <- frases3[c(21,22)]
#Creando la dimension
PCA.introversion <- FactoMineR::PCA(X = DF6 %>%
                                 select(all_of(introversion)),
                               ncp =  1)

# Eigenvalues y varianza explicada : Si voy a agrupar 2 variables, altamente correlacionadas, el PCA representara y encerrara todos los puntos que son equivalentes a las encuestas, si el circulo es como una pelota de fut americano hay alta correlacion, si es una circulo no hay mucha correlacion, EL PCA CREA un nuevo eje x y un nuevo eje y y rota el angulo a tal medida que en un angulo specifico que resume a las dos variables seleccionadas, donde abunda mas el grafico, crea una nueva dimension, la linea que se formara se llama eigenvalues
PCA.introversion$eig

##Correlacion entre la CP1 y las variables originales
PCA.introversion$var$cor


#Añadir las dimensiones al data.frame---- pregunta de examen
DF12<- DF6 %>%
  mutate(
      extroversion = PCA.extroversion$ind$coord,
      aventura = PCA.aventura$ind$coord *-1,
      tradicional = PCA.tradicional$ind$coord *-1,
      empatia = PCA.empatia$ind$coord,
  introversion = PCA.introversion$ind$coord *-1
  )

## Crear un vector de referencia
dimensiones <- c("extroversion",
                 "aventura",
                 "tradicional",
                 "empatia",
                 "introversion")
